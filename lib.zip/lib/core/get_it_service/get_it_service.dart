// service_locator.dart

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:get_it/get_it.dart';
import 'package:logger/logger.dart';
import 'package:rasikh/features/Lawyer/lawyer-home/repo/lawyer_consultations_repo.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:rasikh/config/localization/lang_repo.dart';
import 'package:rasikh/core/app/app_bloc.dart';
import 'package:rasikh/core/cache/cache_helper.dart';
import 'package:rasikh/core/connectivity/cubit/connectivity_cubit.dart';
import 'package:rasikh/core/utils/api/api_handler.dart';
import 'package:rasikh/core/utils/api/api_helper.dart';
import 'package:rasikh/core/utils/api/dio_helper.dart';

import 'package:rasikh/features/common/Auth/bloc/auth_cubit.dart';
import 'package:rasikh/features/common/Auth/repo/auth_repo.dart';
import 'package:rasikh/features/common/splash/bloc/splash_bloc.dart';

import 'package:rasikh/features/Lawyer/lawer_register_compilation/Repo/lawyer_register_complation_repo.dart';
import 'package:rasikh/features/Lawyer/lawyer-appointments/repo/lawyer_appointments_repo.dart';
import 'package:rasikh/features/Lawyer/lawer_register_compilation/cubit/lawyer_registeration_complation_cubit.dart';

import 'package:rasikh/features/User/home/cubit/home_cubit.dart';
import 'package:rasikh/features/User/home/repo/home_repo.dart';
import 'package:rasikh/features/User/profile/repo/profile_repo.dart';

import '../../features/Company/company_register_completion/bloc/company_completion_cubit.dart';
import '../../features/Company/company_register_completion/repo/company_completion_repo.dart';
import '../../features/Lawyer/lawyer-appointments/bloc/lawyer_appointments_cubit.dart';
import '../../features/Lawyer/lawyer-home/bloc/avaiabilty_cubit.dart';
import '../../features/Lawyer/lawyer-home/bloc/lawyer_consultations_cubit.dart';
import '../../features/Lawyer/lawyer-home/repo/lawer_availability_rpeo.dart';
import '../../features/Lawyer/lawyer_Settings/Repo/help_center_repo.dart';
import '../../features/Lawyer/lawyer_Settings/Repo/lawyer_profile_repo.dart';
import '../../features/Lawyer/lawyer_Settings/Repo/specializations_repo.dart';
import '../../features/Lawyer/lawyer_Settings/bloc/Profile_cubit/lawyer_cubit.dart';
import '../../features/Lawyer/lawyer_Settings/bloc/Specializations_cubit/specializations_cubit.dart';
import '../../features/User/application/bloc/consulation_application_cubit.dart';
import '../../features/User/application/repo/consulation_application_repo.dart';
import '../../features/User/profile/bloc/wallet_cubit.dart';
import '../../features/User/profile/cubit/profile_cubit.dart';
import '../../features/User/profile/repo/wallet_repo.dart';
import '../../features/User/user_register_completion/bloc/user_completion_cubit.dart';
import '../../features/User/user_register_completion/repo/user_completion_repo.dart';
import '../../features/common/notifications/bloc/notifications_cubit.dart';
import '../../features/common/notifications/repo/notifications_repo.dart';
import '../theme/theme_cubit/theme_cubit.dart';

export 'package:get_it/get_it.dart';

final GetIt getIt = GetIt.instance;

Future<void> initializeDependencies() async {
  try {
    // ─── SharedPreferences ────────────────────────────────────────────────────
    final sharedPreferences = await SharedPreferences.getInstance();
    getIt.registerSingleton<SharedPreferences>(sharedPreferences);

    // ─── CacheHelper ──────────────────────────────────────────────────────────
    // Init once here; never call init() again in main.dart
    final cacheHelper = CacheHelper();
    await cacheHelper.init();
    getIt.registerSingleton<CacheHelper>(cacheHelper);

    // ─── Networking ───────────────────────────────────────────────────────────
    getIt.registerSingleton<Dio>(Dio());

    // ApiHandler depends on Dio → registered after
    getIt.registerLazySingleton<ApiHandler>(() => ApiHandler());
    getIt.registerLazySingleton<ApiHelper>(() => ApiImpl());
    getIt.registerLazySingleton<DioHelper>(() => DioImpl());

    // ─── Lang ─────────────────────────────────────────────────────────────────
    getIt.registerSingleton<LangRepo>(LangRepo());

    // ─── Auth ─────────────────────────────────────────────────────────────────
    getIt.registerFactory<GeneralAuthRepo>(() => GeneralAuthRepo());
    getIt.registerLazySingleton<AuthCubit>(
          () => AuthCubit(getIt<GeneralAuthRepo>()),
    );

    // ─── Lawyer ───────────────────────────────────────────────────────────────
    getIt.registerLazySingleton<UserCompletionRepo>(
          () => UserCompletionRepo(),
    );
    getIt.registerLazySingleton<UserCompletionCubit>(
          () => UserCompletionCubit(getIt()),
    );


    // ─── Lawyer ───────────────────────────────────────────────────────────────
    getIt.registerLazySingleton<CompanyCompletionRepo>(
          () => CompanyCompletionRepo(),
    );
    getIt.registerLazySingleton<CompanyCompletionCubit>(
          () => CompanyCompletionCubit(getIt()),
    );


    // ─── Lawyer ───────────────────────────────────────────────────────────────
    getIt.registerLazySingleton<LawyerCompletionRepo>(
          () => LawyerCompletionRepo(),
    );
    getIt.registerLazySingleton<LawyerCompletionCubit>(
          () => LawyerCompletionCubit(getIt()),
    );

    // ─── App / Theme ──────────────────────────────────────────────────────────
    // registerFactory: a fresh AppCubit per BlocProvider
    getIt.registerFactory<AppCubit>(() => AppCubit());

    // ─── Splash ───────────────────────────────────────────────────────────────
    // SplashBloc receives CacheHelper + GeneralAuthRepo via constructor
    getIt.registerFactory<SplashBloc>(
          () => SplashBloc(
        getIt<CacheHelper>(),
        getIt<GeneralAuthRepo>(),
      ),
    );

    // ─── Home ─────────────────────────────────────────────────────────────────
    getIt.registerLazySingleton<HomeRepo>(() => HomeRepo());
    // registerLazySingleton so the same HomeCubit instance is reused
    getIt.registerLazySingleton<HomeCubit>(() => HomeCubit());

    // ─── Profile ──────────────────────────────────────────────────────────────
    getIt.registerLazySingleton<ProfileRepo>(() => ProfileRepo());

    // ─── Connectivity ─────────────────────────────────────────────────────────
    getIt.registerLazySingleton<ConnectivityCubit>(() => ConnectivityCubit());


    // Repo — lazySingleton so it is created once and reused
    getIt.registerLazySingleton<LawyerProfileRepo>(
          () => LawyerProfileRepo(),
    );

    // Cubit — factory so each navigation push gets a fresh instance
    // (or use lazySingleton if you want state persisted across screens)
    getIt.registerFactory<LawyerProfileCubit>(
          () => LawyerProfileCubit(getIt<LawyerProfileRepo>()),
    );


    getIt.registerLazySingleton<SpecializationsRepo>(() => SpecializationsRepo());
    getIt.registerFactory<SpecializationsCubit>(() => SpecializationsCubit());



    getIt.registerLazySingleton<NotificationsRepo>(
          () => NotificationsRepo(),
    );

    getIt.registerFactory<NotificationsCubit>(
          () => NotificationsCubit(getIt<NotificationsRepo>()),
    );







    getIt.registerLazySingleton<ConsultationRepo>(
          () => ConsultationRepo(),
    );

    getIt.registerLazySingleton<ConsultationApplicationCubit>(
          () => ConsultationApplicationCubit(),
    );






    getIt.registerLazySingleton<HelpCenterRepo>(
          () => HelpCenterRepo(),
    );

    // ─── Logger ───────────────────────────────────────────────────────────────
    getIt.registerLazySingleton<Logger>(
          () => Logger(
        level: kReleaseMode ? Level.off : Level.debug,
      ),
    );

// Repo — factory so each call gets a fresh instance
    getIt.registerFactory<LawyerAvailabilityRepo>(
          () => LawyerAvailabilityRepo(),
    );

// Cubit — lazy singleton so it survives navigation
    getIt.registerLazySingleton<LawyerAvailabilityCubit>(
          () => LawyerAvailabilityCubit(getIt<LawyerAvailabilityRepo>()),
    );

// Repo — factory so each call gets a fresh instance
    getIt.registerFactory<LawyerConsultationsRepo>(
          () => LawyerConsultationsRepo(),
    );

// Cubit — lazy singleton so it survives navigation
    getIt.registerLazySingleton<LawyerConsultationsCubit>(
          () => LawyerConsultationsCubit(getIt<LawyerConsultationsRepo>()),
    );

    // ── Lawyer Appointments repo (used by LawyerAppointmentsScreen via getIt) ──
    // Register as factory so each consumer gets a fresh instance when requested
    getIt.registerFactory<LawyerAppointmentsRepo>(() => LawyerAppointmentsRepo());




// 2. Register ProfileCubit as a factory so each screen gets a fresh instance
//    when it creates its own BlocProvider.
//    (ProfileScreen and ProfileEditScreen each call BlocProvider internally,
//     so no manual factory is needed – they call getIt<ProfileRepo>() directly.)

// ─── If you want a shared ProfileCubit across HomePage + ProfileScreen ────────
// Register it as a singleton cubit at app level:
    getIt.registerLazySingleton<ProfileCubit>(
          () => ProfileCubit(getIt<ProfileRepo>()),
    );

    // ─── Wallet ───────────────────────────────────────────────────────────────
    getIt.registerLazySingleton<WalletRepo>(() => WalletRepo());
    getIt.registerFactory<WalletCubit>(
          () => WalletCubit(getIt<WalletRepo>()),
    );
  } catch (e, stackTrace) {
    print('Error in initializeDependencies: $e');
    print('StackTrace: $stackTrace');
    rethrow;
  }
}

/// Shared logger instance available app-wide
final logger = getIt.get<Logger>();